## Garbage Collection

<img src = "https://user-images.githubusercontent.com/33534771/83469636-33049780-a4bb-11ea-8135-9bae85b79a10.png" />

### [Minor GC]

- 새로 생성된 대부분의 객체는 Eden 영역에 위치한다. 
- Eden 영역이 꽉 차게 되면 GC가 발생한다. GC가 발생한 이후, 살아남은 객체는 Survivor 영역 중 하나로 이동한다.
- 이 과정을 반복하다가 계속해서 살아남은 객체는 일정 시간 참조되고 있다는 뜻이므로 Old 영역으로 이동한다.



### [Major GC]

- Old 영역에 있는 모든 객체들을 검사하여 참조되고 있지 않은 객체들을 한꺼번에 삭제한다. 
- 시간이 오래 걸리고 실행 중 프로세스가 정지된다. 이것은 'Stop-the-World'라고 하는데, Major GC가 발생하면 GC를 실행하는 스레드를 제외한 나머지 스레드는 모두 작업을 멈춘다. GC 작업을 완료한 이후에야 중단했던 작업을 다시 시작한다.
- GC의 튜닝은 이 'Stop-the-World'의 시간을 줄이는 것이다. 



### [GC는 어떤 원리로 소멸시킬 대상을 선정하는가?]

- 알고리즘에 따라 동작 방식이 매우 다양하지만 공통적인 원리가 있다. 
- Garbage Collector는 힙 내의 객체 중에서 가비지를 찾아내고 찾아낸 가비지를 처리해서 힙의 메모리를 회수한다. 
- **참조되고 있지 않은 객체를 가비지**라고 하며, 객체가 가비지인지 아닌지 판단하기 위해서 `Reachability`라는 개념을 사용한다.
- 어떤 힙 영역에 할당된 객체가 유효한 참조가 있으면 Reachability
- 없다면  UnReachability로 판단한다.
- 하나의 객체는 다른 객체를 참조하고 다른 객체는 또 다른 객체를 참조할 수 있기 때문에 참조 사슬이 형성된다. 이 참조 사슬 중 최초에 참조한 것을 Root Set이라고 한다. 
- 힙 영역에 있는 객체들을 총 4가지 경우에 대한 참조를 하게 된다. 

<img src = "https://user-images.githubusercontent.com/33534771/83470789-0605b400-a4be-11ea-84e6-6044596242d3.png" />


유효한 최초의 참조가 이루어지지 않은 객체들은 Unreachable Objects로 판단하며, GC에 의해 수거된다. 



인스턴스가 가비지 컬렉션의 대상이 되었다고 해서 바로 소멸이 되는 것은 아니다. 빈번한 가비지 컬렉션의 실행은 시스템에 부담이 될 수 있기 때문이다. 그래서 성능에 영향을 미치지 않도록 가비지 컬렉션 실행 타이밍은 별도의 알고리즘을 기반으로 계산이 되며, 이 계산 결과를 바탕으로 GC가 수행된다.



참고할 만한 블로그

- [네이버 D2 블로그](https://d2.naver.com/helloworld/329631)
- [Jungwoon Blog](https://jungwoon.github.io/java,%20gc/2019/07/27/Garbage-Collection.html)

[MIT 라이선스에 따른 출처 표기](https://github.com/WooVictory/Ready-For-Tech-Interview)