## Android에서 Enum 사용

- Android에서 Enum 사용을 자제시키는 이유

Enum의 각 값은 객체이며, 각 선언은 단순히 객체를 참조하기 위해서 런타임 메모리를 사용한다. 따라서 정수 또는 문자열 상수보다 더 많은 메모리를 차지하게 된다.

게다가 단일 Enum을 추가하면 최종 DEX 파일의 크기를 증가시키기에 런타임시 오버헤드가 발생할 수 있고, 앱의 크기가 증가하게 된다.

안드로이드에서는 Enum 대신 TypeDef 어노테이션의 사용을 권장한다.

[MIT 라이선스에 따른 출처 표기](https://github.com/WooVictory/Ready-For-Tech-Interview)
