## int와 short

두 가지 모두 정수형 타입이다. 그렇다면 어떤 차이가 있는지 알아보자.


- `char, short 형` : 이와 같은 정수 자료형 타입으로 표현하면 메모리 공간을 효율적으로 사용할수는 있으나 연산의 효율성은 떨어진다. 
  - size : 2byte(16bits)
- `int 형` : int형보다 작은 크기의 데이터를 가지고 연산을 진행할 경우, 그 데이터를 일단 int형으로 바꿔서 연산을 진행한다. 따라서 산술 연산시, 자료형을 int형으로 선언해야 중간에 불필요한 변환 과정을 거치지 않게 되어 연산 효율이 좋다. 
  - size : 4byte(32bits)

[MIT 라이선스에 따른 출처 표기](https://github.com/WooVictory/Ready-For-Tech-Interview)