### Android - 인터뷰 질문

Q. Android의 4대 컴포넌트에 관한 설명

Q. Activity, Fragment의 차이점은?

Q. Activity, Fragment의 생명주기에 대한 설명

Q. ListView vs RecyclerView

Q. Intent에 관한 설명

Q. Android에서 Thread 구조에 대한 설명

Q. ANR이란?

Q. Thread, Looper, Handler에 대한 설명

Q. Annotation이란?

Q. Context란?

Q. Inflate란?

Q. Singleton 패턴에 관한 설명

Q. MVC, MVP, MVVM 각각에 대한 설명

Q. Dependency Injection이란?

Q. Koin vs Dagger 비교해서 설명

Q. SharedPreferences란?

Q. Image Loading 라이브러리에 대한 설명

Q. DiffUtil이란?

Q. 함수형 프로그래밍이란?

Q. 직렬화 vs 역직렬화에 대한 설명

Q. Java vs Kotlin에 관한 설명

Q. RxJava에서 map, flatMap의 차이점

Q. Immutable이란?

Q. Android enum을 자제시키는 이유는?

Q. Android Process와 Thread에 대한 설명

[MIT 라이선스에 따른 출처 표기](https://github.com/WooVictory/Ready-For-Tech-Interview)